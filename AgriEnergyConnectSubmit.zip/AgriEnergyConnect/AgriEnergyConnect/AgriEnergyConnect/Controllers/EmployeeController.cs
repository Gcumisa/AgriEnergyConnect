﻿using Microsoft.AspNetCore.Mvc;
using AgriEnergyConnect.Data;
using AgriEnergyConnect.Models;

namespace AgriEnergyConnect.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Dashboard()
        {
            if (HttpContext.Session.GetString("UserRole") != "Employee")
                return RedirectToAction("Login", "Account");

            var farmers = _context.Farmers.ToList();
            return View(farmers);
        }

        [HttpGet]
        public IActionResult AddFarmer()
        {
            if (HttpContext.Session.GetString("UserRole") != "Employee")
                return RedirectToAction("Login", "Account");

            return View();
        }

        [HttpPost]
[ValidateAntiForgeryToken]
public IActionResult AddFarmer(Farmer farmer)
{
    if (ModelState.IsValid)
    {
        return RedirectToAction("Dashboard"); 
    }
    return View(farmer);
}

        public IActionResult ViewProducts(int farmerId, string productType, DateTime? startDate, DateTime? endDate)
        {
            var products = _context.Products.Where(p => p.FarmerId == farmerId);

            if (!string.IsNullOrEmpty(productType))
                products = products.Where(p => p.Category == productType);

            if (startDate.HasValue)
                products = products.Where(p => p.ProductionDate >= startDate.Value);

            if (endDate.HasValue)
                products = products.Where(p => p.ProductionDate <= endDate.Value);

            ViewBag.Farmer = _context.Farmers.Find(farmerId);
            return View(products.ToList());
        }
    }
}