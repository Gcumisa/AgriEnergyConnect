﻿using Microsoft.AspNetCore.Mvc;
using AgriEnergyConnect.Data;
using AgriEnergyConnect.Models;
using BCrypt.Net; 
using Microsoft.EntityFrameworkCore;

namespace AgriEnergyConnect.Controllers
{
    public class FarmerController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FarmerController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Shows the Add Farmer form
        [HttpGet]
        public IActionResult AddFarmer()
        {
            return View();
        }

        // POST: Handles form submission
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddFarmer(Farmer farmer)
        {
            if (ModelState.IsValid)
            {
                // Check for duplicate email
                if (_context.Farmers.Any(f => f.Email == farmer.Email))
                {
                    ModelState.AddModelError("Email", "Email already registered");
                    return View(farmer);
                }

                // Hash password and clear confirmation
                farmer.Password = BCrypt.Net.BCrypt.HashPassword(farmer.Password);
                farmer.ConfirmPassword = null;

                // Save to database with error handling
                try
                {
                    _context.Farmers.Add(farmer);
                    _context.SaveChanges(); // This can throw exceptions (e.g., DB errors)

                    TempData["SuccessMessage"] = "Farmer added successfully!";
                    return RedirectToAction("Index"); // Success: redirect to list
                }
                catch (Exception ex)
                {
                    // Log the error (optional, for debugging)
                    // _logger.LogError(ex, "Error saving farmer");

                    // Show user-friendly error
                    ModelState.AddModelError("", "Failed to save farmer. Please try again.");
                    return View(farmer); // Re-display form with error
                }
            }
            return View(farmer); // Model validation failed
        }

        // Existing dashboard action
        public IActionResult Dashboard()
        {
            if (HttpContext.Session.GetString("UserRole") != "Farmer")
                return RedirectToAction("Login", "Account");

            string email = HttpContext.Session.GetString("UserEmail");
            var farmer = _context.Farmers.FirstOrDefault(f => f.Email == email);

            if (farmer == null) return View("NotRegistered");

            var products = _context.Products.Where(p => p.FarmerId == farmer.FarmerId).ToList();
            return View(products);
        }

        [HttpGet]
        public IActionResult AddProduct()
        {
            if (HttpContext.Session.GetString("UserRole") != "Farmer")
                return RedirectToAction("Login", "Account");

            return View();
        }

        [HttpPost]
        public IActionResult AddProduct(Product product)
        {
            string email = HttpContext.Session.GetString("UserEmail");
            var farmer = _context.Farmers.FirstOrDefault(f => f.Email == email);

            if (farmer != null && ModelState.IsValid)
            {
                product.FarmerId = farmer.FarmerId;
                _context.Products.Add(product);
                _context.SaveChanges();
                return RedirectToAction("Dashboard");
            }

            return View(product);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var farmer = _context.Farmers.Find(id);
            if (farmer == null) return NotFound();
            return View(farmer);
        }

        [HttpPost]
        public IActionResult Edit(Farmer farmer)
        {
            if (ModelState.IsValid)
            {
                _context.Update(farmer);
                _context.SaveChanges();
                return RedirectToAction("Dashboard");
            }
            return View(farmer);
        }
    }
}